// /browser-navi/js/ui.js
export { bindUI } from './ui/_index.js';
export { renderQuickLists, toggleFavorite, isFavorite, addHistory } from './ui/favorites.js';
